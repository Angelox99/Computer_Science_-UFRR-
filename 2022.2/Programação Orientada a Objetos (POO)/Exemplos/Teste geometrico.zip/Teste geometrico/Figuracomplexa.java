class Figuracomplexa{
   
    double a1;

    public double getA1() {
        return a1;
    }

    public void setA1(double n) {
        this.a1 = n;
    }

    public Figuracomplexa(double a1) {
        this.a1 = a1;
    }
    
    //Eu tinha feito uma funcao aqui e queria chamar ela la para a calculadora mas entendi muito bem como
    //void Areatotal{
         //return q1.Calculaarea() + q2.Calculaarea() + r1.Calculaarea()+ r2.Calculaarea(); 
      //}

    //ai eu ia chamar o resultado dessa funcao la no calculador; mas nao consegui
}
