class Figuras{

    double area;

    public double Calculaarea(){
       return this.area;
    }
    
}